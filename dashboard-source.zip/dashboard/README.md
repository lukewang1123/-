# 「世界之巅」竞猜球员伤病参考

已检查并升级用户的 1123.zip。无需手填每日赛程；更新器按 **Asia/Shanghai 北京时间** 自动生成今日、次日两天的比赛和参赛球队伤病名单，默认展示次日。界面支持球队 / 球员搜索、风险比赛筛选、来源和报告时间、本地离线快照。

## 手机版与中文展示（第二版）

- 页面顶部按指定标题、日期、公众号文案排列；移除常驻的来源汇总提示，正常情况不显示顶部警告。实际抓取失败或快照过期仍会提示。
- 每场比赛统一单列：对阵 → 客队伤病情况 → 主队伤病情况；手机与电脑均不左右并排球队。
- 球员行直接显示中文名、中文伤情、出战状态；英文原文、报告时间、置信提示与来源保留在“查看详情”中。
- `config/players.zh.json` 保存可维护的中文名词典，覆盖当前快照全部 84 名球员并补充常见球员。部分新秀译名可能有地区差异；英文原名保留供核对。新出现且词典未覆盖的球员不会猜成其他人，而显示球员编号与“中文名待补充”，可在词典追加条目后重新更新。拼写匹配兼容重音符号与标点差异，区分 Jalen / Jaylin Williams。
- 词典随自动更新构建使用，避免下一次抓取恢复英文；中英文姓名均可搜索。
- 部分新秀译名参考：[迪班萨](https://zh.wikipedia.org/wiki/AJ%C2%B7%E8%BF%AA%E7%8F%AD%E8%90%A8)、[2026 选秀](https://zh.wikipedia.org/wiki/2026%E5%B9%B4NBA%E9%80%89%E7%A7%80)、[比贝罗维奇](https://mzht.qiumiwu.com/player/talikebibeiluoweiqi/news)。词典用于展示，球队与比赛仍以原始 ID 匹配。

## 先看页面

解压完整目录，双击 `site/index.html` 即可查看本次交付快照。请保留同目录的 `app.js` 和 `style.css`。此方式显示内嵌数据，**本地 HTML 自己不会在电脑关机时联网更新**。真正无人值守更新由下面的 GitHub Actions 执行。

## GitHub Pages 部署（首次设置一次）

1. 在自己的 GitHub 账号创建仓库，例如 `nba-injury-dashboard`，建议公开仓库。将本目录内容放到仓库根目录：根目录应直接包含 `requirements.txt`、`scripts/`、`web/`、`tests/` 和 **`.github/workflows/update.yml`**，不要多套一层文件夹。上传工具须包括隐藏的 `.github` 目录。
2. 默认分支设为 `main`。如果使用其他分支，修改工作流中的 `push.branches`；定时工作流文件必须位于默认分支。
3. 仓库 **Settings → Pages → Build and deployment → Source → GitHub Actions**。
4. 打开 **Actions → Update NBA dashboard and deploy Pages → Run workflow**。如果 GitHub 提示启用 Actions，先启用。首次 Pages environment 若有审批限制，按自己的仓库设置处理。
5. 等待 `build`、`deploy` 两个任务完成，在 deployment 输出或 Settings → Pages 查看实际站点网址。项目站点通常是 `https://你的账号.github.io/nba-injury-dashboard/`；以 GitHub 返回地址为准。
6. 以后每小时自动更新并发布，无需开电脑，无需 API Key，也不会把自动生成的数据提交进主分支。

**交付时没有指定目标 GitHub 仓库，因此尚未创建仓库或激活线上定时任务；不能把文件里的工作流当作已经运行的服务。** 完成上述设置后才会开始自动部署。本次验证覆盖本地构建与页面，未宣称 GitHub 托管环境已执行成功。

工作流采用 GitHub 官方的 Pages 构建产物与部署机制：
https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## 自动时间与跨日逻辑

- cron 为 `17 * * * *`，UTC 每小时第 17 分钟，即北京时间每天 00:17、01:17……23:17。避开整点，并非准点保证。
- 每次重新计算北京时间日期。10 月 26 日构建默认显示 27 日；27 日构建默认切到 28 日，同时保留今日页，便于追踪临近开赛的变化。
- ESPN 赛程分别请求目标日期前一天、当天两个日期桶，然后将每场实际 UTC 开球时间转换到北京时间过滤、按比赛 ID 去重，避免美国日期与北京时间混用。
- 网页每 5 分钟检查已发布的 `data.json`；“检查更新”同样只读取发布快照，不能触发 GitHub 后台抓取。需要立即抓取时到 Actions 手动 Run workflow。
- GitHub 定时任务可能延迟，极端情况下可能不执行；公开仓库长期（通常 60 天）没有活动时，定时工作流可能自动停用。需在 Actions 检查状态并按 GitHub 提示重新启用。无分钟级可用性保证。详见官方说明：
https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule

## 数据来源与降级

| 数据 | 默认来源 | 失败处理 |
| --- | --- | --- |
| 赛程 | ESPN 公共 scoreboard JSON | NBA 官方全赛季 schedule JSON → 同一北京时间日期的缓存 → 明确显示不可用 |
| 球队伤病名单 | ESPN 公共 injuries JSON | 墨子说球中文表格 → 该球队缓存 → 明确显示不可用 |
| 本场官方报告 | NBA 官方季节报告入口 | 页面提供外链人工核实；本版不解析 PDF，不宣称官方确认 |

- 请求有超时和最多 3 次重试。HTTPS 证书验证保持开启。
- 只有 ESPN 整体伤病源失败才请求墨子备用；不会把两个来源的人名未经核验强行合并，避免同名、译名重复和互相冲突。
- ESPN 缺少某队不代表该队没有伤病，因此该队显示“数据不可用”或旧缓存。原工具的“暂无重要伤病”错误兜底已移除。
- ESPN 是没有本项目 SLA 的公共接口，可能限流、改结构、封禁或停止服务，无法保证实时性、完整性、最终出场、未来球员名单变动。数据按提供方球队 ID / NBA tricode 匹配，不依赖中文译名。
- NBA / 墨子备用适配器均有独立解析测试。**本次现场探测 NBA CDN 返回 403，墨子 HTTPS 证书校验失败，二者当前环境下不能视为已可用的备用服务。** 不绕过证书校验，不声称多源交叉确认；目前实测有效的在线主源是 ESPN，断网时依靠缓存和未知状态。
- 缓存保留各自原来的抓取时间；新一天不会套用前一天赛程。Actions cache 可能因配额、保留期限、分支范围等原因被清除，首次运行或缓存缺失时直接显示未知，不伪造数据。缓存用于降级，不是持久数据库。
- 即使全部来源失败也生成带诊断提示的页面，避免把错误呈现成“0 场比赛 / 全员健康”。Actions 步骤摘要记录来源错误；部署代码异常则停止发布，线上保留上次版本，页面会按时间提示过期。

## 如何理解状态与置信标签

- Out → 来源标记缺阵；Doubtful → 大概率缺席；Questionable / Day-to-day → 成疑 / 每日观察；Probable → 大概率出战；Available → 可出战；未知状态不擅自推断。
- “媒体近期报告”：球员报告在 48 小时以内，且所用名单为新抓取的 ESPN 数据。仍不是本场官方报告。
- “需复核”：球员报告超过 48 小时，或使用缓存、备用来源；较旧的长期伤病可能仍有效，不能仅因旧而删除。
- 墨子来源没有可核验发布时间，始终低可信。抓取时间、源刷新时间、球员报告时间分别显示。
- 快照 / 队伍抓取超过 6 小时会提示过期；源级时间超过 24 小时的 ESPN feed 不当作新数据接受。
- 标签只表达资料质量，**不是统计学概率，不代表确定缺席下一场**。预计回归日期也不是保证。
- NBA 官方要求赛前及比赛日分阶段提交报告，背靠背另有规则，并持续更新。因此提前一天的早晨未必已有完整次日名单。官方规则：
https://official.nba.com/nba-injury-report-2026-27-season/

## 本地更新（Python 3.11+）

在本目录打开终端：

```powershell
py -3 -m pip install -r requirements.txt
py -3 scripts/update.py
py -3 -m http.server 8000 --directory site
```

浏览器打开 `http://localhost:8000`。macOS / Linux 可把 `py -3` 改成 `python3`。Windows 的 IANA 时区数据由 requirements 中的 tzdata 提供。

保留手动覆盖功能，但必须明确启用：复制 `games.example.txt` 为 `games.txt`，按北京时间填写，然后运行：

```powershell
py -3 scripts/update.py --manual-games games.txt
```

支持简称、原工具全称及 tricode；格式 `YYYY-MM-DD 客队 vs 主队 HH:MM`，也兼容 `vs黄蜂` 这种缺空格写法。无效行明确报错，不静默丢失比赛。自动模式永远忽略旧的 `games.txt`。

## 文件说明

- `scripts/update.py`：抓取、归一化、降级、快照与网页生成。
- `web/`：界面源文件；修改后运行更新器。
- `config/players.zh.json`：中文球员名词典，自动构建时读取。
- `site/`：生成好的可打开成品，含 HTML 内嵌快照与 JSON。此目录已被 gitignore，工作流每次重建。
- `.github/workflows/update.yml`：测试 → 缓存恢复 → 抓取 → 缓存保存 → Pages 发布。
- `tests/test_update.py`：有意义的边界 / 故障回归测试。
- `legacy/`：原压缩包 5 个文件完整保留，供回溯，不用于自动构建；其中旧脚本保留原有缺陷，请使用新版。
- `VERIFICATION.md`：本次验证结果与未完成的线上验证边界。

运行测试：`py -3 -m unittest discover -s tests -v`。

原工具没有许可证声明，本项目未擅自指定可再分发许可证。使用和再发布数据应遵守各来源条款。
