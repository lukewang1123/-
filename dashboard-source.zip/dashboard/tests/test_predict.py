import sys, unittest, tempfile, json
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import predict as p

def player(pid,prob=1,rate=.5):
    return {'id':pid,'name':pid,'team':'BOS','gameIndex':0,'playProbability':prob,'minutes':30,'rate':[rate]*5,'size':[8]*5,'recommendationEligible':True}

class Predictions(unittest.TestCase):
    def test_expected_participation_requires_current_evidence(self):
        now=datetime(2026,10,27,10,tzinfo=timezone.utc)
        current=[{'start':'2026-10-25T00:00:00Z'},{'start':'2026-10-26T00:00:00Z'}]
        injury={'state':'fresh','fetchedAt':'2026-10-27T09:00:00Z'}
        self.assertTrue(p.expected_healthy('unknown',[],False,current,30,injury,now))
        self.assertFalse(p.expected_healthy('questionable',[],False,current,30,injury,now))
        self.assertFalse(p.expected_healthy('unknown',[{'player':'x'}],False,current,30,injury,now))
        self.assertFalse(p.expected_healthy('unknown',[],False,current,10,injury,now))
        self.assertFalse(p.expected_healthy('unknown',[],False,current[:1],30,injury,now))
        self.assertFalse(p.expected_healthy('unknown',[],False,current,30,{'state':'cached','fetchedAt':'2026-10-26T09:00:00Z'},now))
    def test_confirmation_gate_rejects_unknown_expired_and_injured(self):
        now=datetime(2026,10,27,10,tzinfo=timezone.utc);game={'id':'g'}
        v={'status':'available','healthy':True,'confirmed':True,'gameId':'g','sourceUrl':'https://example.com/confirmed','verifiedAt':'2026-10-27T09:00:00Z','expiresAt':'2026-10-27T11:00:00Z'}
        self.assertTrue(p.verified_healthy(v,game,now,[]))
        self.assertFalse(p.verified_healthy({},game,now,[]))
        self.assertFalse(p.verified_healthy(v,game,now,[{'status':'questionable'}]))
        self.assertFalse(p.verified_healthy({**v,'expiresAt':'2026-10-27T09:00:00Z'},game,now,[]))
        self.assertFalse(p.verified_healthy(v,{'id':'other'},now,[]))

    def test_unconfirmed_players_not_public_candidates(self):
        a=player('unconfirmed');a['recommendationEligible']=False
        r=p.simulate([a],[{}],1000,5)
        self.assertTrue(all(c['first'] is None and not c['candidates'] for c in r.values()))
    def test_official_advanced_parsing_and_failure(self):
        class Response:
            def raise_for_status(self):pass
            def json(self):return {'resultSets':[{'headers':['TEAM_ID','GP','PACE','OFF_RATING','DEF_RATING'],'rowSet':[[1610612738,4,99,115,111]]}]}
        with patch.object(p.requests,'get',return_value=Response()):
            v=p.advanced_metrics(datetime.now(timezone.utc));self.assertEqual(v['state'],'available');self.assertEqual(v['teams']['BOS']['pace'],99)
        with patch.object(p.requests,'get',side_effect=RuntimeError('403')):
            self.assertEqual(p.advanced_metrics(datetime.now(timezone.utc))['state'],'unavailable')
            self.assertEqual(p.official_injuries(datetime.now(timezone.utc),{},[])['players'],{})

    def test_team_minutes_and_caps(self):
        w=np.array([[80,30,25,20,20,20],[1,1,1,1,1,1]],float)
        a=np.array([[1,1,1,1,1,1],[1,1,1,1,0,0]],bool)
        m=p.allocate_minutes(w,a)
        self.assertTrue(np.all(m<=48+1e-8));self.assertAlmostEqual(m[0].sum(),240)
        self.assertAlmostEqual(m[1].sum(),192);self.assertTrue(np.all(m[1,4:]==0))

    def test_out_players_never_recommended(self):
        r=p.simulate([player('out',0,5),player('in',1,.5)],[{}],1000,8)
        for c in r.values():
            self.assertEqual(c['first']['id'],'in')
            self.assertEqual(c['probabilities']['out']['coLeader'],0)

    def test_zero_stat_ties_split_credit(self):
        r=p.simulate([player('a',1,0),player('b',1,0)],[{}],1000,3)
        for c in r.values():
            self.assertEqual(c['probabilities']['a']['leaderShare'],.5)
            self.assertEqual(c['probabilities']['a']['coLeader'],1)

    def test_seed_reproducibility_and_probability_mass(self):
        args=([player('a'),player('b')],[{}],1000,42)
        a=p.simulate(*args);b=p.simulate(*args);self.assertEqual(a,b)
        for c in a.values():
            self.assertAlmostEqual(sum(v['leaderShare'] for v in c['probabilities'].values()),1,places=5)
            for row in c['candidates']:self.assertAlmostEqual(sum(row['distribution'].values()),1,places=4)

    def test_no_evaluations_means_no_claimed_accuracy(self):
        with tempfile.TemporaryDirectory() as d:
            e=p.evaluate(Path(d),None,datetime.now(timezone.utc))
            self.assertEqual(e['evaluatedDays'],0)
            self.assertIsNone(e['categories']['PTS']['top1HitRate'])

    def test_evaluation_uses_pre_tip_snapshot_and_ties(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);day=root/'forecasts/2026-10-28';day.mkdir(parents=True)
            base={'state':'ready','id':'before','date':'2026-10-28','generatedAt':'2026-10-27T22:00:00Z','games':[{'id':'g','start':'2026-10-28T00:00:00Z'}],'categories':{k:{'candidates':[{'id':'a'},{'id':'b'},{'id':'c'}],'probabilities':{'a':{'coLeader':.6}}} for k in p.STATS}}
            p.dump(day/'before.json',base);p.dump(day/'late.json',{**base,'id':'late','generatedAt':'2026-10-28T01:00:00Z'})
            class C:
                def get(self,*args,**kwargs):return {}
            final={'players':[{'id':'a','values':[10]*5},{'id':'b','values':[10]*5}]}
            with patch.object(p,'parse_summary',return_value=final):e=p.evaluate(root,C(),datetime(2026,10,28,5,tzinfo=timezone.utc))
            record=json.loads((root/'evaluations/2026-10-28.json').read_text())
            self.assertEqual(record['forecastId'],'before');self.assertEqual(e['categories']['PTS']['top1HitRate'],1)
            self.assertEqual(record['scores']['PTS']['winners'],['a','b'])

    def test_incomplete_finals_not_scored(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);d={'state':'ready','id':'x','date':'2026-10-28','generatedAt':'2026-10-27T22:00:00Z','games':[{'id':'g','start':'2026-10-28T00:00:00Z'}]}
            p.dump(root/'forecasts/2026-10-28/a.json',d)
            class C:
                def get(self,*args,**kwargs):return {}
            with patch.object(p,'parse_summary',return_value=None):e=p.evaluate(root,C(),datetime(2026,10,28,5,tzinfo=timezone.utc))
            self.assertEqual(e['evaluatedDays'],0)

if __name__=='__main__':unittest.main()
