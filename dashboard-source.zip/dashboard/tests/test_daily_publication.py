import json, sys, tempfile, unittest
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import pipeline as p

class DailyPublication(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);(self.root/'site').mkdir()
        self.public=self.root/'site/predictions.json'
        self.public.write_text(json.dumps({'publicationDate':'2026-10-26','date':'2026-10-27','id':'previous'}))
        self.calls=0
    def run_model(self,cmd):
        self.calls+=1
        self.assertIn('--no-publish',cmd)
        d={'date':'2026-10-28','generatedAt':'2026-10-27T07:31:00Z','state':'ready','categories':{str(k):{'candidates':[{}, {}, {}]} for k in range(5)}}
        (self.root/'site/predictions-2026-10-28.json').write_text(json.dumps(d))
        return SimpleNamespace(returncode=0)
    def now(self,hour,minute=0):return datetime(2026,10,27,hour,minute,tzinfo=p.BJ)
    def test_before_1530_keeps_yesterday_edition(self):
        before=self.public.read_bytes()
        self.assertEqual(p.publish_daily(self.root,self.now(15,29),self.run_model),'before-cutoff')
        self.assertEqual(self.public.read_bytes(),before);self.assertEqual(self.calls,0)
    def test_at_1530_publishes_tomorrow_once(self):
        self.assertEqual(p.publish_daily(self.root,self.now(15,30),self.run_model),'published')
        before=self.public.read_bytes()
        self.assertEqual(p.publish_daily(self.root,self.now(23),self.run_model),'already-published')
        self.assertEqual(self.calls,1);self.assertEqual(self.public.read_bytes(),before)
    def test_midnight_does_not_replace_fixed_snapshot(self):
        before=self.public.read_bytes()
        self.assertEqual(p.publish_daily(self.root,self.now(0),self.run_model),'before-cutoff')
        self.assertEqual(self.public.read_bytes(),before)
    def test_failure_keeps_previous(self):
        before=self.public.read_bytes()
        self.assertEqual(p.publish_daily(self.root,self.now(15,30),lambda cmd:SimpleNamespace(returncode=2)),'failed-kept-previous')
        self.assertEqual(self.public.read_bytes(),before)
    def test_utc_cutoff_uses_beijing_timezone(self):
        self.assertEqual(p.publish_daily(self.root,datetime(2026,10,27,7,30,tzinfo=timezone.utc),self.run_model),'published')
    def test_old_research_file_cannot_publish_as_new_edition(self):
        self.run_model(['--no-publish'])
        q=self.root/'site/predictions-2026-10-28.json';d=json.loads(q.read_text());d['generatedAt']='2026-10-27T07:00:00Z';q.write_text(json.dumps(d))
        self.assertEqual(p.publish_daily(self.root,self.now(15,30),lambda cmd:SimpleNamespace(returncode=0)),'failed-kept-previous')

if __name__=='__main__':unittest.main()
