import importlib.util
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('update',Path(__file__).resolve().parents[1]/'scripts/update.py')
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
NOW=datetime(2026,10,26,16,30,tzinfo=timezone.utc) # Beijing already Oct 27

def event(id,when):
    return {'id':id,'date':when,'competitions':[{'competitors':[{'homeAway':'away','team':{'id':'13'}},{'homeAway':'home','team':{'id':'26'}}]}]}

class Tests(unittest.TestCase):
    def test_chinese_names_keep_similar_names_distinct(self):
        rows=[{'player':'Jalen Williams','reason':'Ankle'}, {'player':'Jaylin Williams','reason':'Wrist'}, {'player':'Luka Dončić','reason':'Back'}]
        u.localize({'OKC':{'players':rows}})
        self.assertEqual(rows[0]['playerZh'],'杰伦·威廉姆斯')
        self.assertEqual(rows[1]['playerZh'],'杰林·威廉姆斯')
        self.assertEqual(rows[2]['playerZh'],'卢卡·东契奇')
        self.assertEqual(rows[0]['reasonZh'],'脚踝伤势')
        self.assertEqual(rows[0]['player'],'Jalen Williams')
    def test_unmapped_name_does_not_invent_identity(self):
        row={'player':'New Unknown Player','id':'123','reason':'New Medical Term'}
        u.localize({'LAL':{'players':[row]}})
        self.assertEqual(row['playerZh'],'New Unknown Player')
        self.assertTrue(row['nameNeedsReview'])
        self.assertEqual(row['reasonZh'],'伤情待核实')
        self.assertEqual(row['player'],'New Unknown Player')
    def test_missing_live_player_names_are_localized(self):
        expected={'Sergio de Larrea':'塞尔吉奥·德·拉雷亚','Jaxson Hayes':'贾克森·海斯','Justin Champagnie':'贾斯汀·尚帕尼','Isaiah Stewart':'以赛亚·斯图尔特'}
        rows=[{'player':name,'reason':'Ankle'} for name in expected]
        u.localize({'LAL':{'players':rows}})
        for row in rows:
            self.assertEqual(row['playerZh'],expected[row['player']])
            self.assertFalse(row['nameNeedsReview'])

    def test_beijing_boundaries_and_dedup(self):
        p={'events':[event('excluded','2026-10-26T15:59Z'),event('first','2026-10-26T16:00Z'),event('last','2026-10-27T15:59Z'),event('next','2026-10-27T16:00Z')]}
        games=u.parse_espn_games([p,p],'2026-10-27')
        self.assertEqual([g['id'] for g in games],['first','last'])
        self.assertEqual(games[0]['away']['name'],'湖人')
    def test_missing_schedule_schema_is_not_no_games(self):
        with self.assertRaises(ValueError):u.parse_espn_games([{}],'2026-10-27')
        self.assertEqual(u.parse_espn_games([{'events':[]}],'2026-10-27'),[])
    def test_status_no_invented_certainty(self):
        self.assertEqual(u.status_key('Day-To-Day'),'questionable')
        self.assertEqual(u.status_key('new status'),'unknown')
    def test_stale_feed_rejected(self):
        with self.assertRaises(ValueError):u.parse_injuries({'timestamp':'2026-01-01T00:00Z','injuries':[{}]},NOW)
    def test_nba_backup(self):
        p={'leagueSchedule':{'gameDates':[{'games':[{'gameId':'1','gameDateTimeUTC':'2026-10-26T23:00:00Z','homeTeam':{'teamTricode':'UTA'},'awayTeam':{'teamTricode':'LAL'}}]}]}}
        self.assertEqual(u.parse_nba_games(p,'2026-10-27')[0]['home']['code'],'UTA')
    def test_legacy_manual_spacing(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'games.txt';f.write_text('2026-10-27 湖人 vs爵士 7:00',encoding='utf-8')
            self.assertEqual(u.manual_games(f,'2026-10-27')[0]['start'],'2026-10-26T23:00:00Z')
            f.write_text('bad line',encoding='utf-8')
            with self.assertRaises(ValueError):u.manual_games(f,'2026-10-27')
    def test_mozi_unknown_timestamp(self):
        p=u.parse_mozi('<table><tr><td>洛杉矶湖人 返回顶部</td><td>A</td><td>缺席</td><td>脚踝</td><td>待定</td></tr></table>',NOW)
        self.assertIsNone(p['LAL']['players'][0]['reportedAt'])
        self.assertEqual(p['LAL']['state'],'fallback')
    def test_mozi_rowspan_preserves_players(self):
        html='<table><tr><td rowspan="2">湖人</td><td>A</td><td>缺席</td><td>脚踝</td><td>待定</td></tr><tr><td>B</td><td>每日观察</td><td>膝盖</td><td>待定</td></tr></table>'
        rows=u.parse_mozi(html,NOW)['LAL']['players']
        self.assertEqual([r['player'] for r in rows],['A','B'])
        self.assertEqual(rows[1]['status'],'questionable')
    def test_failure_cache_never_crosses_dates(self):
        with tempfile.TemporaryDirectory() as d:
            old={'days':{'2026-10-27':{'games':[{'id':'prior'}],'state':'fresh','source':'ESPN','fetchedAt':'2026-10-26T00:00Z'}},'injuries':{'LAL':{'state':'fresh','source':'ESPN','fetchedAt':'2026-10-26T00:00Z','players':[]}}}
            (Path(d)/'data.json').write_text(json.dumps(old),encoding='utf-8')
            with patch.object(u,'get',side_effect=RuntimeError('offline')):
                r=u.build(NOW,d)
            self.assertEqual(r['defaultDate'],'2026-10-28')
            self.assertEqual(r['days']['2026-10-27']['state'],'cached')
            self.assertEqual(r['days']['2026-10-28']['state'],'unavailable')
            self.assertEqual(r['injuries']['LAL']['fetchedAt'],'2026-10-26T00:00Z')
            self.assertEqual(r['injuries']['UTA']['state'],'unavailable')
    def test_embedded_json_escapes_script(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(u,'get',side_effect=RuntimeError('</script><script>alert(1)</script>')):
                u.build(NOW,d)
            html=(Path(d)/'index.html').read_text(encoding='utf-8')
            self.assertNotIn('</script><script>alert',html)
            raw=html.split('<script id="snapshot" type="application/json">')[1].split('</script>')[0]
            self.assertEqual(json.loads(raw)['schemaVersion'],1)

if __name__=='__main__':unittest.main()
