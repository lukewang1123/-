import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from sync_names import parse

class NameSync(unittest.TestCase):
    def test_only_pairs_with_chinese_and_english_are_imported(self):
        html='''<table class="players_table"><tr><td class="left"><b><a>鲁迪-戈贝尔</a></b><p>(<b>Rudy Gobert</b>)</p></td></tr>
        <tr><td class="left"><b><a>NBA广告</a></b></td></tr>
        <tr><td class="left"><b><a>�-坏编码</a></b><p><b>Bad Name</b></p></td></tr></table>'''
        self.assertEqual(parse(html),{'Rudy Gobert':'鲁迪·戈贝尔'})

