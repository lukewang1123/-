"""Refresh bilingual roster names daily; retain bundled names if the provider fails."""
import concurrent.futures as cf
import json, re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]

def parse(html):
    soup=BeautifulSoup(html,'html.parser');names={}
    for cell in soup.select('table.players_table td.left'):
        zh=cell.select_one('b a');en=cell.select_one('p b')
        if zh and en:
            chinese=zh.get_text(strip=True).replace('-', '·').replace('—','·')
            english=en.get_text(strip=True)
            if re.search(r'[\u3400-\u9fff]',chinese) and re.search('[A-Za-z]',english) and '�' not in chinese:
                names[english]=chinese
    return names

def fetch(url):
    response=requests.get(url,timeout=15);response.raise_for_status()
    return response.content.decode('utf-8')

def sync(root=ROOT):
    today=datetime.now(ZoneInfo('Asia/Shanghai')).date().isoformat()
    path=root/'config/players.zh.json';known=json.loads(path.read_text(encoding='utf-8-sig'))
    cache=root/'runtime/name-translations.json'
    try: saved=json.loads(cache.read_text(encoding='utf-8'))
    except (OSError,ValueError):saved={}
    if saved.get('date')!=today:
        try:
            soup=BeautifulSoup(fetch('https://nba.hupu.com/players'),'html.parser')
            urls=sorted({a['href'] for a in soup.select('a[href]') if re.fullmatch(r'https://nba.hupu.com/players/[a-z0-9]+',a['href'])})
            if len(urls)!=30:raise ValueError('Expected all 30 roster pages')
            with cf.ThreadPoolExecutor(max_workers=5) as pool:
                results=list(pool.map(fetch,urls))
            names={}
            for html in results:
                team=parse(html)
                if len(team)<8:raise ValueError('Incomplete bilingual roster')
                names.update(team)
            if len(names)<350:raise ValueError('Incomplete league roster')
            saved={'date':today,'source':'https://nba.hupu.com/players','names':names}
            cache.parent.mkdir(parents=True,exist_ok=True)
            temp=cache.with_suffix('.tmp');temp.write_text(json.dumps(saved,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(cache)
        except Exception as exc:print('Chinese name refresh deferred; retain bundled dictionary:',type(exc).__name__)
    # Curated local translations take precedence over the external spelling.
    merged={**saved.get('names',{}),**known}
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(dict(sorted(merged.items())),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');temp.replace(path)
    print('Chinese player name dictionary:',len(merged))
    return merged

if __name__=='__main__':sync()
