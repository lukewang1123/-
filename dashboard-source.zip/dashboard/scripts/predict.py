"""Auditable next-Beijing-day NBA leader forecast. No bookmaker odds or betting actions."""
from __future__ import annotations
import argparse, concurrent.futures as cf, hashlib, io, json, math, os, re, time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urljoin
from zoneinfo import ZoneInfo
import numpy as np
import requests
from bs4 import BeautifulSoup
from pypdf import PdfReader
import update

ROOT=Path(__file__).resolve().parents[1]
UTC=timezone.utc
BJ=ZoneInfo('Asia/Shanghai')
BASE=update.BASE
STATS=('PTS','REB','AST','BLK','STL')
ZH=dict(zip(STATS,('得分','篮板','助攻','盖帽','抢断')))
VERSION='healthy-expected-top3-v1.2'
PROBS={'out':0.,'doubtful':.15,'questionable':.5,'probable':.85,'available':.98,'unknown':.9}
TEAM_IDS=dict(zip(update.CODES,update.IDS))
NBA_TEAMS=dict(zip(range(1610612737,1610612767),'ATL BOS CLE NOP CHI DAL DEN GSW HOU LAC LAL MIA MIL MIN BKN NYK ORL IND PHI PHX POR SAC SAS OKC TOR UTA MEM WAS DET CHA'.split()))
CODE={'WSH':'WAS','GS':'GSW','NY':'NYK','SA':'SAS','NO':'NOP','UTAH':'UTA','PHO':'PHX'}

def stamp(d):return d.astimezone(UTC).isoformat().replace('+00:00','Z')
def instant(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def canon(s):return CODE.get(s,s)
def key(s):return re.sub(r'[^a-z0-9]','',s.lower())
def verified_healthy(record,game,now,injury_list):
    """Only explicit, fresh game-specific confirmation. Absence from injury list is insufficient."""
    try:
        return (record.get('status')=='available' and record.get('healthy') is True
            and record.get('confirmed') is True and str(record.get('gameId'))==str(game['id'])
            and str(record.get('sourceUrl','')).startswith('https://')
            and 0<=(now-instant(record['verifiedAt'])).total_seconds()<=6*3600
            and now<instant(record['expiresAt'])
            and not injury_list)
    except (KeyError,ValueError,TypeError):return False

def expected_healthy(status,listed,official_listed,current,minutes,injury,now):
    """Recommendation evidence, not a claim of confirmed actual participation."""
    try:
        return (status in ('unknown','available') and not listed and not official_listed
            and len(current)>=2 and minutes>=18
            and 0<=(now-instant(current[-1]['start'])).total_seconds()<7*86400
            and injury.get('state') in ('fresh','fallback')
            and 0<=(now-instant(injury['fetchedAt'])).total_seconds()<6*3600)
    except (KeyError,ValueError,TypeError):return False
def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(temp,path)

class Client:
    def __init__(self,cache,now):self.cache=cache;cache.mkdir(parents=True,exist_ok=True);self.now=now;self.diagnostics=[]
    def get(self,url,ttl=300):
        p=self.cache/(hashlib.sha256(url.encode()).hexdigest()+'.json')
        if p.exists() and time.time()-p.stat().st_mtime<ttl:
            return json.loads(p.read_text(encoding='utf-8'))['body']
        last=None
        for _ in range(2):
            try:
                r=requests.get(url,timeout=18,headers={'User-Agent':'NBAResearchDashboard/1.0'});r.raise_for_status();body=r.json()
                dump(p,{'url':url,'observedAt':stamp(self.now),'body':body});return body
            except (requests.RequestException,ValueError) as e:last=e
        raise RuntimeError(f'{url}: {last}')
    def many(self,items,fn):
        results=[]
        with cf.ThreadPoolExecutor(max_workers=6) as ex:
            futures={ex.submit(fn,x):x for x in items}
            for f in cf.as_completed(futures):
                try:results.append((futures[f],f.result()))
                except Exception as e:self.diagnostics.append({'resource':str(futures[f]),'error':str(e)[:350]})
        return results

def numeric(s):
    try:return float(str(s).replace(',',''))
    except (TypeError,ValueError):return 0.

def parse_summary(body):
    h=body.get('header',{});comp=h.get('competitions',[{}])[0]
    if not comp.get('status',{}).get('type',{}).get('completed'):return None
    start=h.get('competitions',[{}])[0].get('date') or h.get('date')
    if not start:raise ValueError('summary missing game date')
    teams={};players=[]
    for t in body.get('boxscore',{}).get('teams',[]):
        c=canon(t['team']['abbreviation']);s={x['name']:x.get('displayValue','') for x in t.get('statistics',[])}
        def attempt(k):return numeric(str(s.get(k,'0-0')).split('-')[-1])
        poss=attempt('fieldGoalsMade-fieldGoalsAttempted')+.44*attempt('freeThrowsMade-freeThrowsAttempted')-numeric(s.get('offensiveRebounds'))+numeric(s.get('totalTurnovers',s.get('turnovers')))
        teams[c]={'poss':max(60.,poss),'stats':{k:numeric(s.get(n)) for k,n in zip(STATS,('points','totalRebounds','assists','blocks','steals'))}}
    competitors=comp.get('competitors',[])
    for t in competitors:
        c=canon(t.get('team',{}).get('abbreviation',''))
        if c in teams:teams[c]['stats']['PTS']=numeric(t.get('score'))
    for group in body.get('boxscore',{}).get('players',[]):
        c=canon(group['team']['abbreviation'])
        for block in group.get('statistics',[]):
            labels=block.get('labels',[])
            if not all(k in labels for k in ('MIN',*STATS)):continue
            for row in block.get('athletes',[]):
                if row.get('didNotPlay') or not row.get('stats'):continue
                s=dict(zip(labels,row['stats']));mins=s.get('MIN','0')
                mins=sum(float(x)/(60**i) for i,x in enumerate(mins.split(':'))) if ':' in mins else numeric(mins)
                if mins<=0:continue
                a=row['athlete'];players.append({'id':str(a['id']),'name':a['displayName'],'team':c,'minutes':mins,'starter':bool(row.get('starter')),'position':a.get('position',{}).get('abbreviation','F'),'values':[numeric(s[k]) for k in STATS]})
    if len(teams)!=2 or not players:raise ValueError('incomplete final box score')
    # Use both teams' possession estimate; normalize overtime to 48 minutes.
    total_minutes=sum(p['minutes'] for p in players)/2
    duration=max(48.,total_minutes/5)
    pace=sum(t['poss'] for t in teams.values())/2*48/duration
    return {'id':str(h['id']),'start':start,'teams':teams,'players':players,'pace':pace}

def history(client,now,days):
    # Previous April supplies a shrunk prior at season start. Preseason is excluded.
    dates={(now-timedelta(days=i)).strftime('%Y%m%d') for i in range(days+1)}
    if now.month in (10,11):
        dates.update(f'{now.year}04{i:02d}' for i in range(1,16))
    events={}
    for _,body in client.many(sorted(dates),lambda d:client.get(BASE+'scoreboard?dates='+d+'&limit=1000',ttl=900 if d>=now.strftime('%Y%m%d') else 86400)):
        for e in body.get('events',[]):
            if e.get('season',{}).get('type')!=2:continue
            if e.get('status',{}).get('type',{}).get('completed') and instant(e['date'])<now:events[e['id']]=e
    games=[]
    for eid,body in client.many(sorted(events),lambda eid:client.get(BASE+'summary?event='+eid,ttl=86400*7)):
        try:
            game=parse_summary(body)
            if game and instant(game['start'])<now:games.append(game)
        except Exception as e:client.diagnostics.append({'resource':eid,'error':str(e)})
    return sorted(games,key=lambda x:(x['start'],x['id']))

def official_injuries(now,rosters,games):
    """Conservative name/date/matchup matching; any ambiguity is left unknown."""
    year=now.year if now.month>=7 else now.year-1
    url=f'https://official.nba.com/nba-injury-report-{year}-{str(year+1)[-2:]}-season/'
    result={'state':'unavailable','url':url,'checkedAt':stamp(now),'players':{},'note':''}
    try:
        r=requests.get(url,timeout=15);r.raise_for_status();soup=BeautifulSoup(r.text,'html.parser')
        links=[urljoin(url,a['href']) for a in soup.select('a[href]') if re.search(r'Injury-Report_.*\.pdf',a['href'])]
        def issued(u):
            m=re.search(r'(\d{4}-\d{2}-\d{2})_(\d{2})_(\d{2})(AM|PM)',u)
            if not m:return datetime.min.replace(tzinfo=UTC)
            d,h,mi,ap=m.groups();h=int(h)%12+(12 if ap=='PM' else 0)
            return datetime.fromisoformat(d).replace(hour=h,minute=int(mi),tzinfo=ZoneInfo('America/New_York')).astimezone(UTC)
        links=[u for u in links if 0<=(now-issued(u)).total_seconds()<8*3600]
        if not links:raise ValueError('no official report issued within last 8 hours')
        pdf=max(links,key=issued);r=requests.get(pdf,timeout=20);r.raise_for_status()
        text='\n'.join(p.extract_text(extraction_mode='layout') or '' for p in PdfReader(io.BytesIO(r.content)).pages)
        expected={frozenset((g['away']['code'],g['home']['code'])) for g in games}
        valid_dates={instant(g['start']).astimezone(ZoneInfo('America/New_York')).strftime('%m/%d/%Y') for g in games}
        matchup=None;date=None
        names={}
        for c,athletes in rosters.items():
            for a in athletes:
                bits=a['name'].split();names[(c,key(bits[-1]+''.join(bits[:-1])))]=a['id']
        for line in text.splitlines():
            d=re.search(r'\b\d{2}/\d{2}/\d{4}\b',line)
            if d:date=d.group()
            m=re.search(r'\b([A-Z]{2,4})@([A-Z]{2,4})\b',line)
            if m:matchup=frozenset(canon(c) for c in m.groups())
            if date not in valid_dates or matchup not in expected:continue
            m=re.search(r'([A-Za-z .\-\'’]+,\s*[A-Za-z .\-\'’]+?)\s{2,}(Out|Doubtful|Questionable|Probable|Available)\b',line)
            if not m:continue
            name,status=m.groups()
            matches=[(c,pid) for (c,k),pid in names.items() if c in matchup and k==key(name)]
            if len(matches)==1:result['players'][matches[0][1]]=status.lower()
        result.update(state='available' if result['players'] else 'unmatched',url=pdf,issuedAt=stamp(issued(pdf)),matchedPlayers=len(result['players']),note='仅使用姓名、比赛日期及对阵均匹配的官方条目；未列出不代表确认健康')
    except Exception as e:result['note']=str(e)[:300]
    return result

def advanced_metrics(now):
    year=now.year if now.month>=7 else now.year-1
    url='https://stats.nba.com/stats/leaguedashteamstats'
    result={'state':'unavailable','url':url,'checkedAt':stamp(now),'teams':{}}
    params={'LeagueID':'00','MeasureType':'Advanced','PerMode':'PerGame','PlusMinus':'N','PaceAdjust':'N','Rank':'N','Season':f'{year}-{str(year+1)[-2:]}','SeasonType':'Regular Season','LastNGames':'0','Month':'0','OpponentTeamID':'0','Period':'0','DateFrom':'','DateTo':'','GameScope':'','Location':'','Outcome':'','PORound':'0','SeasonSegment':'','VsConference':'','VsDivision':'','PlayerExperience':'','PlayerPosition':'','StarterBench':''}
    try:
        r=requests.get(url,params=params,timeout=10,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.nba.com/'});r.raise_for_status()
        for block in r.json().get('resultSets',[]):
            for values in block.get('rowSet',[]):
                row=dict(zip(block.get('headers',[]),values));c=NBA_TEAMS.get(row.get('TEAM_ID'))
                if c and row.get('GP',0)>0 and 60<float(row.get('PACE',0))<140:
                    result['teams'][c]={'pace':float(row['PACE']),'offRating':float(row['OFF_RATING']),'defRating':float(row['DEF_RATING']),'games':row['GP']}
        if not result['teams']:raise ValueError('no valid advanced-stat rows')
        result['state']='available'
    except Exception as e:result['note']=str(e)[:300]
    return result

def fit_players(rosters,games,hist,snapshot,official,overrides,advanced=None):
    records=defaultdict(list);teamhist=defaultdict(list);positions=defaultdict(list)
    for game in hist:
        for p in game['players']:
            row={**p,'start':game['start'],'pace':game['pace']};records[p['id']].append(row);positions[p['position']].append(row)
        for c,t in game['teams'].items():
            opp=next(x for x in game['teams'] if x!=c)
            teamhist[c].append({'pace':game['pace'],'off':t['stats'],'allowed':game['teams'][opp]['stats'],'start':game['start']})
    allrows=[r for rs in records.values() for r in rs]
    if len(allrows)<100:raise ValueError('too few verified historical player observations; forecast suppressed')
    league=np.sum([r['values'] for r in allrows],axis=0)/sum(r['minutes'] for r in allrows)
    leaguepace=float(np.mean([g['pace'] for g in hist]))
    allowed=np.mean([list(t['allowed'].values()) for ts in teamhist.values() for t in ts],axis=0)
    mapping=json.loads((ROOT/'config/players.zh.json').read_text(encoding='utf-8'))
    # Reuse the injury tool's localized dictionary shape.
    if 'players' in mapping:mapping=mapping['players']
    players=[];coverage=[];metrics={}
    season_start=f"{instant(games[0]['start']).year if instant(games[0]['start']).month>=7 else instant(games[0]['start']).year-1}-07-01"
    for gi,g in enumerate(games):
        for c,opp in ((g['away']['code'],g['home']['code']),(g['home']['code'],g['away']['code'])):
            recentteam=teamhist[c][-12:];recentopp=teamhist[opp][-12:]
            pace=(sum(t['pace'] for t in recentteam+recentopp)+8*leaguepace)/(len(recentteam+recentopp)+8)
            oppallow=(np.sum([list(t['allowed'].values()) for t in recentopp],axis=0)+8*allowed)/(len(recentopp)+8) if recentopp else allowed
            off=np.mean([t['off']['PTS']/t['pace']*100 for t in recentteam]) if recentteam else 0
            defense=np.mean([t['allowed']['PTS']/t['pace']*100 for t in recentteam]) if recentteam else 0
            metrics[c]={'paceEstimate':round(pace,2),'offensiveRatingEstimate':round(float(off),2),'defensiveRatingEstimate':round(float(defense),2),'sampleGames':len(recentteam),'kind':'由基础技术统计估算，非官方进阶指标'}
            adv=(advanced or {}).get('teams',{})
            if c in adv and opp in adv:
                pace=(adv[c]['pace']+adv[opp]['pace'])/2
                metrics[c]={'pace':adv[c]['pace'],'offRating':adv[c]['offRating'],'defRating':adv[c]['defRating'],'sampleGames':adv[c]['games'],'kind':'NBA Stats official Advanced'}
            unknown=0
            for a in rosters.get(c,[]):
                rs=sorted(records[a['id']],key=lambda x:x['start']);current=[r for r in rs if r['start']>=season_start and r['team']==c]
                if not rs:unknown+=1
                recent=current[-5:] or rs[-5:]
                pos=positions[a['position']];posrate=(np.sum([r['values'] for r in pos],axis=0)+240*league)/(sum(r['minutes'] for r in pos)+240) if pos else league
                prior=[r for r in rs if r['start']<season_start]
                # Exposure shrinkage: position -> prior season player -> current season -> last five.
                base=(np.sum([r['values'] for r in prior],axis=0)+180*posrate)/(sum(r['minutes'] for r in prior)+180) if prior else posrate
                rate=(np.sum([r['values'] for r in current],axis=0)+180*base)/(sum(r['minutes'] for r in current)+180) if current else base
                rec_rate=(np.sum([r['values'] for r in recent],axis=0)+100*rate)/(sum(r['minutes'] for r in recent)+100) if recent else rate
                rate=.65*rate+.35*rec_rate
                minutes=(sum(r['minutes'] for r in recent)+2*20)/(len(recent)+2) if recent else 6.
                if current and (instant(g['start'])-instant(current[-1]['start'])).days>14:minutes*=.65
                status='unknown';source='未列伤病不代表确认出场'
                injury=snapshot.get('injuries',{}).get(c,{})
                for i in injury.get('players',[]):
                    if key(i['player'])==key(a['name']):
                        if injury.get('fetchedAt') and (instant(official.get('checkedAt',snapshot['generatedAt']))-instant(injury['fetchedAt'])).total_seconds()<6*3600:
                            status=i['status'];source='备用媒体伤病名单'
                        else:source='伤病缓存过期，视为未知'
                if a['id'] in official['players']:status=official['players'][a['id']];source='NBA官方报告匹配条目'
                override=overrides.get(a['id'],{})
                listed=[i for i in injury.get('players',[]) if key(i['player'])==key(a['name'])]
                check_at=instant(official.get('checkedAt',snapshot['generatedAt']))
                confirmed=verified_healthy(override,g,check_at,listed) and a['id'] not in official['players']
                if override.get('status') in PROBS:status=override['status'];source='运营校正（非官方）'
                if 'minutes' in override:minutes=float(np.clip(override['minutes'],0,48))
                eligible=confirmed or expected_healthy(status,listed,a['id'] in official['players'],current,minutes,injury,check_at)
                prob=PROBS.get(status,.9)
                if eligible and not confirmed:prob=.95
                b2b=bool(current and (instant(g['start'])-instant(current[-1]['start'])).total_seconds()<30*3600)
                if b2b:minutes*=.97
                context=np.clip((pace/leaguepace)*(oppallow/np.maximum(allowed,.1)),.8,1.2)
                if c in adv and opp in adv:
                    avgdef=np.mean([v['defRating'] for v in adv.values()])
                    context[0]=np.clip((pace/leaguepace)*(adv[opp]['defRating']/avgdef),.8,1.2)
                name=mapping.get(a['name'],a['name'])
                if isinstance(name,dict):name=name.get('zh',a['name'])
                # Gamma-Poisson size: empirical game variance with prior regularization.
                vals=np.array([r['values'] for r in recent])
                mu=rate*minutes
                var=np.var(vals,axis=0) if len(vals)>1 else mu+mu*mu/8
                size=np.clip(mu*mu/np.maximum(var-mu,.1),2,60)
                players.append({'id':a['id'],'name':name,'nameOriginal':a['name'],'team':c,'teamName':update.NAMES[update.CODES.index(c)],'gameId':g['id'],'gameIndex':gi,'position':a['position'],'status':status,'recommendationEligible':eligible,'recommendationBasis':'明确出场确认' if confirmed else '未列伤病+本队近期至少2场+预计18分钟以上（非确认出场）','confirmation':override if confirmed else None,'injuryEvidence':source,'playProbability':prob,'minutes':minutes,'minuteSource':'运营校正' if 'minutes' in override else '历史轮换模型估计，未确认首发','rate':(rate*context).tolist(),'size':size.tolist(),'samples':len(rs),'currentSamples':len(current),'confidence':'样本较少' if len(rs)<5 else '模型估计，未校准','reasons':[f'历史样本{len(rs)}场，本季{len(current)}场；近5场向赛季/位置均值收缩',f'对手与节奏修正{context[0]:.2f}倍；预计出场概率为启发式假设',('背靠背分钟折减3%' if b2b else '非背靠背/样本未检测到背靠背')],'mean':mu.tolist()})
            coverage.append({'team':c,'rosterPlayers':len(rosters.get(c,[])),'noHistory':unknown})
    return players,coverage,metrics

def allocate_minutes(weights,active):
    """Project each team onto <=48 minutes/player, <=240 team minutes per simulation."""
    w=np.where(active,weights,0.).copy();out=np.zeros_like(w)
    remain=np.full(w.shape[0],240.)
    for _ in range(w.shape[1]+1):
        denom=w.sum(axis=1);candidate=w/np.maximum(denom[:,None],1e-12)*remain[:,None]
        capped=candidate>48
        if not capped.any():out+=candidate;break
        out+=np.where(capped,48.,0.);remain-=capped.sum(axis=1)*48;w[capped]=0
    return out

def simulate(players,games,n=20000,seed=20261027):
    if n<100:raise ValueError('simulation count too low')
    rng=np.random.default_rng(seed);count=len(players)
    active=rng.random((n,count))<np.array([p['playProbability'] for p in players])
    weights=np.maximum(0,rng.normal([p['minutes'] for p in players],3.5,(n,count)))
    mins=np.zeros_like(weights)
    for c in sorted({p['team'] for p in players}):
        idx=[i for i,p in enumerate(players) if p['team']==c]
        mins[:,idx]=allocate_minutes(weights[:,idx],active[:,idx])
    gi=np.array([p['gameIndex'] for p in players])
    # Shared game pace / overtime and player form induce positive dependence.
    gamefactor=rng.lognormal(-.5*.065**2,.065,(n,len(games)))
    overtime=np.where(rng.random((n,len(games)))<.06,53/48,1.)
    form=rng.lognormal(-.5*.08**2,.08,(n,count))
    rates=np.array([p['rate'] for p in players]);size=np.array([p['size'] for p in players])
    result={}
    for j,k in enumerate(STATS):
        mean=mins*rates[:,j]*gamefactor[:,gi]*overtime[:,gi]*form
        latent=rng.gamma(size[:,j],np.maximum(mean,1e-12)/size[:,j])
        values=rng.poisson(latent);values[~active]=0
        lead=(values==values.max(axis=1,keepdims=True)) & active
        share=lead/np.maximum(lead.sum(axis=1,keepdims=True),1)
        threshold=np.partition(values,-min(3,count),axis=1)[:,-min(3,count)]
        candidates=[]
        for i,p in enumerate(players):
            # Competition rank: ties share rank. Top3 event may include >3 players.
            top3=np.mean((values[:,i]>=threshold)&active[:,i])
            candidates.append({k:v for k,v in p.items() if k not in ('rate','size','mean','gameIndex')}|{'expected':round(float(values[:,i].mean()),2),'p10':float(np.quantile(values[:,i],.1)),'p90':float(np.quantile(values[:,i],.9)),'leaderShare':round(float(share[:,i].mean()),6),'coLeaderProbability':round(float(lead[:,i].mean()),6),'top3Probability':round(float(top3),6),'expectedMinutes':round(float(mins[:,i].mean()),1)})
        candidates.sort(key=lambda x:(-x['leaderShare'],-x['expected'],x['id']))
        by_id={p['id']:i for i,p in enumerate(players)}
        ranked=[p for p in candidates if p['playProbability']>0 and p.get('recommendationEligible',False)]
        for p in ranked[:3]:
            vals,counts=np.unique(values[:,by_id[p['id']]],return_counts=True)
            p['distribution']={str(int(v)):round(float(c/n),6) for v,c in zip(vals,counts)}
        result[k]={'label':ZH[k],'first':ranked[0] if ranked else None,'candidates':ranked[:3],'probabilities':{p['id']:{'leaderShare':p['leaderShare'],'coLeader':p['coLeaderProbability']} for p in candidates}}
    return result

def evaluate(state,client,now):
    evaluated=[]
    for folder in sorted((state/'forecasts').glob('*')):
        files=sorted(folder.glob('*.json'));eligible=[]
        for f in files:
            d=json.loads(f.read_text(encoding='utf-8'))
            if d.get('state')=='ready' and instant(d['generatedAt'])<min(instant(g['start']) for g in d['games']):eligible.append(d)
        if not eligible:continue
        pred=max(eligible,key=lambda x:x['generatedAt']);path=state/'evaluations'/f'{pred["date"]}.json'
        if path.exists() and json.loads(path.read_text(encoding='utf-8')).get('forecastId')==pred['id']:continue
        # Only freeze pre-first-tip snapshots; do not score retrospective or partial-day picks.
        if now<max(instant(g['start']) for g in pred['games'])+timedelta(hours=2):continue
        finals=[]
        for g in pred['games']:
            try:
                b=client.get(BASE+'summary?event='+g['id'],ttl=300);v=parse_summary(b)
                if v:finals.append(v)
            except Exception:pass
        if len(finals)!=len(pred['games']):continue
        actual=defaultdict(lambda:np.zeros(5))
        for g in finals:
            for p in g['players']:actual[p['id']]+=np.array(p['values'])
        scores={}
        for j,k in enumerate(STATS):
            maximum=max(v[j] for v in actual.values());winners=sorted(pid for pid,v in actual.items() if v[j]==maximum)
            ranked=pred['categories'][k]['candidates'];probs=pred['categories'][k]['probabilities']
            # Co-leader event calibration; includes actual unmodelled participants with p=0.
            ids=set(actual)|set(probs);pairs=[{'p':probs.get(pid,{}).get('coLeader',0.),'y':int(pid in winners)} for pid in ids]
            scores[k]={'actualMax':float(maximum),'winners':winners,'top1Hit':ranked[0]['id'] in winners if ranked else None,'top3Hit':bool(set(p['id'] for p in ranked[:3])&set(winners)) if ranked else None,'brier':float(np.mean([(x['p']-x['y'])**2 for x in pairs])),'calibrationPairs':pairs,'unmodelledPlayers':sorted(set(actual)-set(probs))}
        record={'date':pred['date'],'forecastId':pred['id'],'forecastAt':pred['generatedAt'],'evaluatedAt':stamp(now),'scores':scores};dump(path,record)
    for f in (state/'evaluations').glob('*.json') if (state/'evaluations').exists() else []:evaluated.append(json.loads(f.read_text(encoding='utf-8')))
    aggregate={}
    for k in STATS:
        rows=[e['scores'][k] for e in evaluated if e['scores'][k]['top1Hit'] is not None];bins=[]
        for lo in np.arange(0,1,.1):
            ps=[p for r in rows for p in r['calibrationPairs'] if lo<=p['p']<lo+.1 or (lo>.89 and p['p']==1)]
            bins.append({'from':round(float(lo),1),'count':len(ps),'meanProbability':float(np.mean([p['p'] for p in ps])) if ps else None,'observedFrequency':float(np.mean([p['y'] for p in ps])) if ps else None})
        aggregate[k]={'days':len(rows),'top1HitRate':float(np.mean([r['top1Hit'] for r in rows])) if rows else None,'top3HitRate':float(np.mean([r['top3Hit'] for r in rows])) if rows else None,'brier':float(np.mean([r['brier'] for r in rows])) if rows else None,'calibrationBins':bins}
    return {'evaluatedDays':len(evaluated),'categories':aggregate,'note':'Top3命中率=推荐前三人至少一人并列或独占日榜第一；非球员实际排名前三。概率校准为并列第一事件可靠性分箱，未做事后拟合校准。'}

def run(args):
    now=datetime.now(UTC);state=Path(args.state);state.mkdir(parents=True,exist_ok=True)
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    client=Client(state/'cache',now)
    snapshot=json.loads((output/'data.json').read_text(encoding='utf-8'))
    tomorrow=(now.astimezone(BJ).date()+timedelta(days=1)).isoformat()
    target=args.date or tomorrow
    day=snapshot.get('days',{}).get(target,{})
    games=[g for g in day.get('games',[]) if g.get('status') not in ('Postponed','Canceled','Cancelled')]
    if games and min(instant(g['start']) for g in games)<=now:
        # Do not quietly remove completed games and change the all-day competition.
        stats=evaluate(state,client,now)
        previous=output/f'predictions-{target}.json'
        if previous.exists():
            frozen=json.loads(previous.read_text(encoding='utf-8'));frozen['locked']=True;frozen['evaluation']=stats;dump(previous,frozen)
            return frozen
        locked={'schemaVersion':1,'state':'locked','date':target,'generatedAt':stamp(now),'simulations':args.simulations,'categories':{},'warnings':['当日已开赛，缺少赛前快照，不补造预测'],'evaluation':stats}
        dump(previous,locked);return locked
    result={'schemaVersion':1,'model':VERSION,'generatedAt':stamp(now),'date':target,'simulations':args.simulations,'seed':args.seed,'state':'unavailable','games':games,'categories':{},'warnings':[]}
    try:
        if day.get('state')!='fresh':raise ValueError('next-day schedule is not freshly verified')
        if not games:result['state']='no_games'
        else:
            codes=sorted({g[side]['code'] for g in games for side in ('away','home')});rosters={}
            for c,b in client.many(codes,lambda c:client.get(BASE+f'teams/{TEAM_IDS[c]}/roster',ttl=600)):
                rosters[c]=[{'id':str(a['id']),'name':a['displayName'],'position':a.get('position',{}).get('abbreviation','F')} for a in b.get('athletes',[]) if str(a.get('id',''))]
            if any(len(rosters.get(c,[]))<8 for c in codes):raise ValueError('incomplete rosters: suppress whole-day rankings')
            hist=history(client,now,args.history_days)
            official=official_injuries(now,rosters,games);result['officialInjuries']=official
            overrides={}
            availability_url=os.environ.get('NBA_AVAILABILITY_URL','')
            if availability_url:
                try:
                    if not availability_url.startswith('https://'):raise ValueError('availability provider must use HTTPS')
                    av=client.get(availability_url,ttl=120)
                    if av['date']==target and instant(av['expiresAt'])>now:overrides.update(av.get('players',{}))
                except Exception as e:result['warnings'].append('出场确认服务不可用：'+str(e)[:200])
            if args.overrides:
                ov=json.loads(Path(args.overrides).read_text(encoding='utf-8'))
                if instant(ov['expiresAt'])>now and ov['date']==target:overrides.update(ov.get('players',{}))
                else:result['warnings'].append('运营校正已过期或日期不符，未应用')
            advanced=advanced_metrics(now);result['advancedStats']=advanced
            players,coverage,metrics=fit_players(rosters,games,hist,snapshot,official,overrides,advanced)
            if any(sum(p['playProbability']>0 for p in players if p['team']==c)<5 for c in codes):raise ValueError('fewer than five potentially active players for a team')
            fingerprint=hashlib.sha256(json.dumps({'players':players,'games':games,'overrides':overrides},sort_keys=True).encode()).hexdigest()
            result.update(state='ready',inputHash=fingerprint,coverage=coverage,teamMetrics=metrics,historyGames=len(hist),categories=simulate(players,games,args.simulations,args.seed))
            result['warnings']+=['V1为分层收缩与启发式参数模型，概率尚未经过前瞻校准；不保证准确率','分钟/轮换由历史估计，未接入可靠自动首发确认源；阵容变动按每次抓取重算','球员比赛内和对阵节奏存在共享随机因素；尚非完整攻防回合模拟']
            if official['state']!='available':result['warnings'].append('官方伤病报告暂不可用，当前为备用媒体伤病信息；未列出视为未知')
            if advanced['state']!='available':result['warnings'].append('NBA官方进阶接口不可用，球队及对手指标降级为基础技术统计估算')
            result['warnings'].append('媒体伤病快照可能含缓存条目，出场概率为状态映射假设，非官方概率')
            result['historyCoverage']={'start':hist[0]['start'] if hist else None,'end':hist[-1]['start'] if hist else None,'note':'当前滚动历史 + 开季上赛季4月先验，不等于完整生涯或完整赛季'}
    except Exception as e:result['warnings'].append(str(e))
    for label,value in (('NBA official injury',result.get('officialInjuries')),('NBA official advanced',result.get('advancedStats'))):
        if value and value['state']!='available':client.diagnostics.append({'resource':label,'error':value.get('note',value['state'])})
    result['diagnostics']=client.diagnostics
    result['probabilityNote']='概率为未校准模型在当前假设下的模拟频率；20000次的最坏蒙特卡洛标准误约0.35个百分点，不包含模型和输入误差。'
    result['evaluation']=evaluate(state,client,now)
    identity=hashlib.sha256(json.dumps({k:v for k,v in result.items() if k!='evaluation'},sort_keys=True).encode()).hexdigest()[:16];result['id']=identity
    dump(state/'forecasts'/target/f'{now.strftime("%Y%m%dT%H%M%SZ")}-{identity}.json',result)
    dump(output/f'predictions-{target}.json',result)
    if target==tomorrow and not getattr(args,'no_publish',False):dump(output/'predictions.json',result)
    dump(state/'health.json',{'at':stamp(now),'state':result['state'],'warnings':result['warnings'],'failedResources':len(client.diagnostics)})
    print(json.dumps({'state':result['state'],'date':target,'games':len(games),'historyGames':result.get('historyGames',0),'warnings':result['warnings'],'failedResources':len(client.diagnostics)},ensure_ascii=False))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--no-publish',action='store_true',help='Write dated research output without replacing the published daily edition');p.add_argument('--output',default=str(ROOT/'site'));p.add_argument('--state',default=str(ROOT/'runtime'));p.add_argument('--date',help='Explicit Beijing date, normally today for pre-tip refresh');p.add_argument('--simulations',type=int,default=20000);p.add_argument('--seed',type=int,default=20261027);p.add_argument('--history-days',type=int,default=28);p.add_argument('--overrides');a=p.parse_args();r=run(a)
    if r['state']=='unavailable':raise SystemExit(2)
