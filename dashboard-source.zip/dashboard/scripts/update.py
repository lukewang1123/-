"""NBA snapshots: Beijing calendar, explicit provenance, conservative failure states."""
import argparse
import hashlib
import json
import os
import re
import shutil
import time
import unicodedata
from datetime import datetime, timedelta, timezone, date
from pathlib import Path
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
BJ = ZoneInfo('Asia/Shanghai')
UTC = timezone.utc
BASE = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/'
MOZI = 'https://www.mozishuoqiu.com/index.php/Injury/lst'
NBA = 'https://cdn.nba.com/static/json/staticData/scheduleLeagueV2_1.json'
# Stable tricode is the join key, never a translated display name.
CODES = 'ATL BOS BKN CHA CHI CLE DAL DEN DET GSW HOU IND LAC LAL MEM MIA MIL MIN NOP NYK OKC ORL PHI PHX POR SAC SAS TOR UTA WAS'.split()
NAMES = '老鹰 凯尔特人 篮网 黄蜂 公牛 骑士 独行侠 掘金 活塞 勇士 火箭 步行者 快船 湖人 灰熊 热火 雄鹿 森林狼 鹈鹕 尼克斯 雷霆 魔术 76人 太阳 开拓者 国王 马刺 猛龙 爵士 奇才'.split()
FULL = '亚特兰大老鹰 波士顿凯尔特人 布鲁克林篮网 夏洛特黄蜂 芝加哥公牛 克利夫兰骑士 达拉斯独行侠 丹佛掘金 底特律活塞 金州勇士 休斯顿火箭 印第安纳步行者 洛杉矶快船 洛杉矶湖人 孟菲斯灰熊 迈阿密热火 密尔沃基雄鹿 明尼苏达森林狼 新奥尔良鹈鹕 纽约尼克斯 俄克拉荷马城雷霆 奥兰多魔术 费城76人 菲尼克斯太阳 波特兰开拓者 萨克拉门托国王 圣安东尼奥马刺 多伦多猛龙 犹他爵士 华盛顿奇才'.split()
IDS = '1 2 17 30 4 5 6 7 8 9 10 11 12 13 29 14 15 16 3 18 25 19 20 21 22 23 24 28 26 27'.split()
BY_ID = dict(zip(IDS, CODES))
ZH = dict(zip(CODES, NAMES))
ALIASES = dict(zip(NAMES, CODES)) | dict(zip(FULL, CODES)) | {c:c for c in CODES} | {'GS':'GSW','SA':'SAS','NY':'NYK','NO':'NOP','WSH':'WAS','UTAH':'UTA','PHO':'PHX','BRK':'BKN'}


def name_key(name):
    return re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD',name).encode('ascii','ignore').decode().lower())


def localize(injuries):
    names=json.loads((ROOT/'config/players.zh.json').read_text(encoding='utf-8-sig'))
    lookup={name_key(k):v for k,v in names.items()}
    reasons={'Ankle':'脚踝伤势','Knee':'膝盖伤势','Foot':'足部伤势','Achilles':'跟腱伤势',
        'Hamstring':'腿筋伤势','Calf':'小腿伤势','Hip':'髋部伤势','Groin':'腹股沟伤势',
        'Back':'背部伤势','Shoulder':'肩部伤势','Wrist':'手腕伤势','Hand':'手部伤势',
        'Thumb':'拇指伤势','Finger':'手指伤势','Elbow':'肘部伤势','Forearm':'前臂伤势',
        'Head':'头部伤势','Concussion':'脑震荡','Illness':'生病','Personal':'个人原因',
        'Personal Reasons':'个人原因','Rest':'轮休','Injury Management':'伤病管理',
        'Oblique':'腹斜肌伤势','Abdomen':'腹部伤势','Neck':'颈部伤势','Heel':'脚跟伤势',
        'Leg':'腿部伤势','Toe':'脚趾伤势','Chest':'胸部伤势','Ribs':'肋部伤势',
        'Quad':'股四头肌伤势','Quadriceps':'股四头肌伤势','Thigh':'大腿伤势',
        'Shin':'胫部伤势','Pelvis':'骨盆伤势','Not Injury Related':'非伤病原因',
        'Undisclosed':'伤情未公开','Other':'其他原因','Undisclosed Injury':'伤情未公开'}
    for value in injuries.values():
        for row in value['players']:
            original=row['player']
            row['playerZh']=original if re.search(r'[\u3400-\u9fff]',original) else lookup.get(name_key(original))
            row['nameNeedsReview']=not bool(row['playerZh'])
            if not row['playerZh']:
                row['playerZh']=original or '未公布姓名'
            reason=row.get('reason','未注明')
            row['reasonZh']=reasons.get(reason,reason if re.search(r'[\u3400-\u9fff]',reason) else '伤情待核实')


def stamp(d):
    return d.astimezone(UTC).isoformat().replace('+00:00', 'Z')


def instant(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00'))


def code(t):
    return BY_ID.get(str(t.get('id')), ALIASES.get(t.get('abbreviation', ''), t.get('teamTricode', '')))


def team(c):
    if c not in ZH:
        raise ValueError('Unknown team: ' + c)
    return {'code': c, 'name': ZH[c]}


def get(url, kind='json'):
    error = None
    for attempt in range(3):
        try:
            r = requests.get(url, timeout=(8, 25), headers={'User-Agent':'NBAInjuryDashboard/1.0 (personal research)', 'Accept':'application/json,text/html'})
            r.raise_for_status()
            return r.json() if kind == 'json' else r.text
        except (requests.RequestException, ValueError) as exc:
            error = exc
            if attempt < 2:
                time.sleep(1 + attempt)
    raise RuntimeError(f'{url}: {error}')


def parse_espn_games(payloads, target):
    found = {}
    for payload in payloads:
        if not isinstance(payload.get('events'), list):
            raise ValueError('ESPN schedule schema changed')
        for e in payload['events']:
            when = instant(e['date'])
            if when.astimezone(BJ).date().isoformat() != target:
                continue
            comp = e['competitions'][0]
            sides = {c['homeAway']: team(code(c['team'])) for c in comp['competitors']}
            found[e['id']] = {'id':e['id'], 'start':stamp(when), **sides,
                'status':e.get('status',{}).get('type',{}).get('description','Scheduled'),
                'venue':comp.get('venue',{}).get('fullName',''), 'source':'ESPN'}
    return sorted(found.values(), key=lambda g:g['start'])


def parse_nba_games(payload, target):
    days = payload['leagueSchedule']['gameDates']
    if not days:
        raise ValueError('NBA schedule empty / unavailable season')
    result = []
    for day in days:
        for g in day['games']:
            when = instant(g['gameDateTimeUTC'])
            if when.astimezone(BJ).date().isoformat() == target:
                result.append({'id':str(g['gameId']), 'start':stamp(when),
                    'home':team(g['homeTeam']['teamTricode']), 'away':team(g['awayTeam']['teamTricode']),
                    'status':g.get('gameStatusText','Scheduled'), 'venue':g.get('arenaName',''), 'source':'NBA'})
    return sorted(result, key=lambda g:g['start'])


def schedule(target, notices):
    d = date.fromisoformat(target)
    try:
        # US date indexes differ from Beijing dates; fetch both calendar buckets, then filter timestamps.
        payloads = [get(BASE+'scoreboard?dates='+x.strftime('%Y%m%d')+'&limit=1000') for x in (d-timedelta(days=1),d)]
        return parse_espn_games(payloads,target), 'ESPN', 'fresh'
    except Exception as exc:
        notices.append('ESPN 赛程失败：'+str(exc))
    try:
        return parse_nba_games(get(NBA),target), 'NBA', 'fresh'
    except Exception as exc:
        notices.append('NBA 备用赛程失败：'+str(exc))
    return None, None, 'unavailable'


def status_key(raw):
    s = raw.lower()
    if s in ('out','o') or '缺席' in s or '赛季报销' in s: return 'out'
    if 'doubtful' in s: return 'doubtful'
    if 'questionable' in s or 'day-to-day' in s or '出战成疑' in s or '每日观察' in s: return 'questionable'
    if 'probable' in s: return 'probable'
    if s in ('available','active'): return 'available'
    return 'unknown'


def parse_injuries(p, now):
    if not isinstance(p.get('injuries'),list) or not p['injuries']:
        raise ValueError('ESPN injury feed empty or schema changed')
    # Feed refresh time is different from each player's last reported date.
    feed_at = p.get('timestamp')
    if not feed_at or (now-instant(feed_at)).total_seconds() > 86400 or instant(feed_at) > now+timedelta(hours=1):
        raise ValueError('ESPN feed timestamp missing, stale or in future')
    out = {}
    for t in p['injuries']:
        c = BY_ID.get(str(t['id']))
        if not c: continue
        if not isinstance(t.get('injuries'),list): raise ValueError('Invalid team injury list')
        rows = []
        for i in t['injuries']:
            a = i['athlete']; detail = i.get('details') or {}; raw = i.get('status','Unknown')
            if not a.get('displayName'): raise ValueError('Missing player name')
            updated = i.get('date')
            age = (now-instant(updated)).total_seconds()/3600 if updated else None
            rows.append({'player':a['displayName'], 'id':str(a.get('id','')), 'status':status_key(raw),
                'rawStatus':raw, 'reason':detail.get('type') or '未注明',
                'timeline':detail.get('returnDate') or '未公布', 'note':i.get('shortComment',''),
                'reportedAt':updated, 'source':'ESPN', 'sourceUrl':'https://www.espn.com/nba/injuries',
                'confidence':'需复核' if age is None or age>48 else '媒体近期报告',
                'scope':'球队伤病名单，非本场官方确认'})
        out[c] = {'state':'fresh','source':'ESPN','fetchedAt':stamp(now),'sourceUpdatedAt':feed_at,'players':rows}
    if len(out)<10: raise ValueError('ESPN injury feed suspiciously incomplete')
    return out


def parse_mozi(html, now):
    soup = BeautifulSoup(html,'html.parser'); out = {}
    for table in soup.find_all('table'):
        c = None; rows = []
        for tr in table.find_all('tr'):
            cells = [td.get_text(' ',strip=True) for td in tr.find_all('td')]
            if not cells: continue
            candidate = ALIASES.get(cells[0].replace('返回顶部','').strip())
            if candidate: c = candidate
            fields = cells[1:] if candidate else cells if c and len(cells)==4 else []
            if len(fields)>=4 and fields[0]:
                rows.append({'player':fields[0], 'status':status_key(fields[1]), 'rawStatus':fields[1],
                    'reason':fields[2], 'timeline':fields[3], 'note':'备用中文来源，未提供可核验发布时间。',
                    'reportedAt':None,'source':'墨子说球','sourceUrl':MOZI,'confidence':'低 · 时间未知',
                    'scope':'球队伤病名单，非本场官方确认'})
        if c and rows: out[c]={'state':'fallback','source':'墨子说球','fetchedAt':stamp(now),'sourceUpdatedAt':None,'players':rows}
    if not out: raise ValueError('墨子说球未找到可识别的 NBA 伤病表格')
    return out


def manual_games(path,target):
    games=[]
    for n,line in enumerate(Path(path).read_text(encoding='utf-8-sig').splitlines(),1):
        if not line.strip() or line.lstrip().startswith('#'): continue
        m=re.fullmatch(r'(\d{4}-\d{2}-\d{2})\s+(.+?)\s*vs\s*(.+?)\s+(\d{1,2}:\d{2})',line.strip(),re.I)
        if not m: raise ValueError(f'games.txt 第 {n} 行格式错误')
        day,away,home,clock=m.groups()
        when=datetime.fromisoformat(day+'T'+clock.zfill(5)).replace(tzinfo=BJ)
        if day==target:
            games.append({'id':f'manual-{n}', 'start':stamp(when),'away':team(ALIASES.get(away,away)),
                'home':team(ALIASES.get(home,home)), 'status':'手动赛程','venue':'','source':'手动'})
    return games


def build(now, output, manual=None):
    output=Path(output); output.mkdir(parents=True,exist_ok=True)
    old={}
    try: old=json.loads((output/'data.json').read_text(encoding='utf-8'))
    except (OSError,ValueError): pass
    notices=[]; injuries={}
    try: injuries=parse_injuries(get(BASE+'injuries'),now)
    except Exception as exc: notices.append('ESPN 伤病获取失败：'+str(exc))
    # Only query secondary source when primary fails, avoiding needless requests.
    if not injuries:
        try: injuries=parse_mozi(get(MOZI,'html'),now)
        except Exception as exc: notices.append('墨子说球备用源失败：'+str(exc))
    for c in CODES:
        if c not in injuries:
            previous=old.get('injuries',{}).get(c)
            if previous and previous.get('state')!='unavailable':
                injuries[c]={**previous,'state':'cached'}
            else:
                injuries[c]={'state':'unavailable','source':None,'fetchedAt':None,'players':[]}
    localize(injuries)
    days={}
    for offset in (0,1):
        target=(now.astimezone(BJ).date()+timedelta(days=offset)).isoformat()
        if manual:
            games,source,state=manual_games(manual,target),'手动','manual'
        else: games,source,state=schedule(target,notices)
        if games is None:
            previous=old.get('days',{}).get(target)
            if previous and previous.get('state')!='unavailable':
                days[target]={**previous,'state':'cached'}
            else: days[target]={'games':[],'state':'unavailable','source':None,'fetchedAt':None}
        else: days[target]={'games':games,'state':state,'source':source,'fetchedAt':stamp(now)}
    result={'schemaVersion':1, 'generatedAt':stamp(now),'timezone':'Asia/Shanghai',
        'defaultDate':(now.astimezone(BJ).date()+timedelta(days=1)).isoformat(),
        'days':days,'injuries':injuries,'notices':notices,
        'officialUrl':f'https://official.nba.com/nba-injury-report-{now.year if now.month>=7 else now.year-1}-{str((now.year+1) if now.month>=7 else now.year)[-2:]}-season/'}
    text=json.dumps(result,ensure_ascii=False,indent=2)
    # Atomic replacement; interrupting a write cannot corrupt the last good snapshot.
    temp=output/'data.tmp'; temp.write_text(text,encoding='utf-8'); os.replace(temp,output/'data.json')
    for f in ('style.css','app.js','predictions.js'): shutil.copyfile(ROOT/'web'/f,output/f)
    shutil.copytree(ROOT/'web/assets',output/'assets',dirs_exist_ok=True)
    template=(ROOT/'web/index.html').read_text(encoding='utf-8')
    version=hashlib.sha256(b''.join((ROOT/'web'/f).read_bytes() for f in ('app.js','style.css','predictions.js'))).hexdigest()[:12]
    template=template.replace('__ASSET_VERSION__',version)
    embedded=json.dumps(result,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    (output/'index.html').write_text(template.replace('__SNAPSHOT__',embedded),encoding='utf-8')
    prediction_template=(ROOT/'web/predictions.html').read_text(encoding='utf-8')
    (output/'predictions.html').write_text(prediction_template.replace('__ASSET_VERSION__',version),encoding='utf-8')
    (output/'.nojekyll').touch()
    summary=os.environ.get('GITHUB_STEP_SUMMARY')
    if summary:
        with open(summary,'a',encoding='utf-8') as f:
            f.write('## NBA snapshot\n\n'+result['generatedAt']+'\n\n')
            for day,value in days.items():
                f.write(f"- {day}: {len(value['games'])} games / {value['state']}\n")
            f.write('\nWarnings:\n\n'+ ('\n'.join('- '+n.replace('\n',' ') for n in notices) or 'None')+'\n')
        for n in notices:
            print('::warning::'+n.replace('%','%25').replace('\r','%0D').replace('\n','%0A'))
    print(json.dumps({'generatedAt':result['generatedAt'],'days':{k:{'games':len(v['games']),'state':v['state']} for k,v in days.items()},'injurySources':sorted({v['source'] for v in injuries.values() if v['source']}),'warnings':notices},ensure_ascii=False,indent=2))
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',default=str(ROOT/'site'))
    p.add_argument('--manual-games',help='Explicit override only; never silently use obsolete games.txt')
    args=p.parse_args()
    build(datetime.now(UTC),args.output,args.manual_games)
