"""Run injury dashboard, pre-tip refresh, next-day forecast and forward evaluation."""
import json, subprocess, sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    subprocess.run([sys.executable,str(ROOT/'scripts/update.py')],check=True)
    failures=[]
    today=datetime.now(ZoneInfo('Asia/Shanghai')).date().isoformat()
    for args in (['--date',today],[]):
        cmd=[sys.executable,str(ROOT/'scripts/predict.py'),*args]
        if (ROOT/'config/overrides.json').exists():cmd+=['--overrides',str(ROOT/'config/overrides.json')]
        if subprocess.run(cmd).returncode:failures.append(args or ['tomorrow'])
    if failures:
        print('Prediction unavailable for some dates; injury output remains generated:',failures)
        # Deployment should still publish the explicit unavailable state, not an old recommendation.
        (ROOT/'runtime/pipeline-warning.json').write_text(json.dumps(failures),encoding='utf-8')
