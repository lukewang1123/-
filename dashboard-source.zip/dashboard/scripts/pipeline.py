"""Refresh injuries independently; freeze one successful Beijing 16:00 edition."""
import json, subprocess, sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
BJ=ZoneInfo('Asia/Shanghai')

def read(path):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}

def publish_daily(root=ROOT,now=None,runner=subprocess.run):
    now=(now or datetime.now(BJ)).astimezone(BJ)
    if now.hour<16:return 'before-cutoff'
    edition=now.date().isoformat()
    target=(now.date()+timedelta(days=1)).isoformat()
    public=root/'site/predictions.json'
    if read(public).get('publicationDate','')>=edition:return 'already-published'
    cmd=[sys.executable,str(root/'scripts/predict.py'),'--date',target,'--no-publish']
    if (root/'config/overrides.json').exists():cmd+=['--overrides',str(root/'config/overrides.json')]
    result=runner(cmd)
    forecast=read(root/'site'/f'predictions-{target}.json')
    try:
        observed=datetime.fromisoformat(forecast['generatedAt'].replace('Z','+00:00')).astimezone(BJ)
        fresh=observed.date()==now.date() and observed.hour>=16
    except (KeyError,ValueError,TypeError):fresh=False
    complete=forecast.get('state')=='no_games' or (forecast.get('state')=='ready' and len(forecast.get('categories',{}))==5 and all(len(c.get('candidates',[]))==3 for c in forecast['categories'].values()))
    if result.returncode or forecast.get('date')!=target or not fresh or not complete:return 'failed-kept-previous'
    forecast['publicationDate']=edition
    forecast['publicationPolicy']='Beijing 16:00 daily; immutable after successful publication'
    public.parent.mkdir(parents=True,exist_ok=True)
    temp=public.with_suffix('.tmp');temp.write_text(json.dumps(forecast,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(public)
    return 'published'

if __name__=='__main__':
    subprocess.run([sys.executable,str(ROOT/'scripts/update.py')],check=True)
    print('Daily prediction:',publish_daily())
    # Score completed games without modifying the frozen public edition.
    try:
        import predict
        now=datetime.now(predict.UTC)
        predict.evaluate(ROOT/'runtime',predict.Client(ROOT/'runtime/cache',now),now)
    except Exception as exc:
        print('Evaluation deferred:',exc)
