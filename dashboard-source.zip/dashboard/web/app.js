'use strict';
let data=JSON.parse(document.getElementById('snapshot').textContent);
let selected=data.defaultDate;
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const bjDay=d=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
const clock=s=>s?new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s)):'时间未知';
const labels={out:'缺席',doubtful:'大概率缺席',questionable:'出战成疑',probable:'可能出战',available:'可以出战',unknown:'待核实'};
const stateLabels={fresh:'',fallback:'备用来源 · 需复核',cached:'历史缓存 · 需复核',unavailable:'数据未收录'};
const gameLabels={Scheduled:'未开赛','Pre-Game':'未开赛','In Progress':'进行中',Final:'已结束',Postponed:'已延期',Canceled:'已取消',Cancelled:'已取消','Halftime':'中场休息'};
function age(s){return s?(Date.now()-new Date(s).getTime())/3600000:Infinity;}
function teamHTML(t){
  const v=data.injuries[t.code]||{state:'unavailable',players:[]};
  const stale=age(v.fetchedAt)>6||v.state!=='fresh';
  const records=v.players.map(i=>{
    const confidence=stale?'需复核 · 缓存或备用':(age(i.reportedAt)>48?'需复核':i.confidence);
    const url=/^https:\/\//.test(i.sourceUrl||'')?i.sourceUrl:'#';
    const name=i.playerZh||(/[\u3400-\u9fff]/.test(i.player)?i.player:'中文名待补充');
    const reason=i.reasonZh||(/[\u3400-\u9fff]/.test(i.reason)?i.reason:'伤情待核实');
    return `<div class="injury" role="listitem"><div class="player-line"><strong>${esc(name)}</strong><span class="reason">${esc(reason)}</span><span class="status ${esc(i.status)}">${esc(labels[i.status]||labels.unknown)}</span></div><details><summary>查看详情${i.nameNeedsReview?' · 中文名待补充':''}</summary><div class="detail-body"><p><span class="badge ${confidence.includes('复核')||confidence.includes('低')?'warn':''}">${esc(confidence)}</span> · 球员报告 ${esc(clock(i.reportedAt))}</p><p>预计回归：${esc(i.timeline)}（仅供参考）</p><p>数据来源：<a href="${esc(url)}" target="_blank" rel="noopener">${esc(i.source)} ↗</a> · 抓取 ${esc(clock(v.fetchedAt))}</p><p>原文姓名：${esc(i.player)}<br>原文伤情：${esc(i.reason)} · ${esc(i.rawStatus)}</p><p>${esc(i.note||'来源未附说明。')}</p><p>${esc(i.scope)}</p></div></details></div>`;
  }).join('');
  return `<section class="team"><div class="team-title"><h3>${esc(t.name)}伤病情况</h3><small>${esc(stateLabels[v.state]||'')}</small></div>${records?`<div class="table-head" aria-hidden="true"><span>球员</span><span>伤病情况</span><span>出战状态</span></div><div role="list">${records}</div>`:`<div class="empty">${v.state==='unavailable'?'暂未取得该队伤病名单，请以赛前最新消息为准。':'该来源暂未收录伤病球员，不代表官方确认全员健康。'}</div>`}</section>`;
}
function render(){
  const days=Object.keys(data.days).sort();
  if(!data.days[selected])selected=data.defaultDate;
  const today=bjDay(new Date());
  $('dates').innerHTML=days.map(d=>`<button type="button" data-date="${esc(d)}" class="${selected===d?'active':''}" aria-pressed="${selected===d}">${d===today?'今日':d===bjDay(new Date(Date.now()+86400000))?'明日':d.slice(5)} <small>${d.slice(5)}</small></button>`).join('');
  const day=data.days[selected];
  const [y,m,d]=selected.split('-');
  $('hero-date').textContent=`${y}年${Number(m)}月${Number(d)}日 · 北京时间`;
  $('date-label').textContent=day.state==='unavailable'?'赛程待更新':`${day.games.length} 场比赛`;
  // Keep ordinary source diagnostics out of the header; show only an actual update failure or stale snapshot.
  const warnings=[];
  if(day.state==='unavailable')warnings.push('赛程暂未获取成功，请稍后查看。');
  else if(day.state==='cached')warnings.push('当前展示历史赛程，请以最新消息为准。');
  if(age(data.generatedAt)>6||today>days[0])warnings.push('数据更新暂时延迟，当前展示旧快照。');
  $('health').hidden=!warnings.length;
  $('health').textContent=warnings.join(' ');
  const q=$('search').value.trim().toLowerCase();
  const games=day.games.filter(g=>{
    const rows=[...(data.injuries[g.away.code]?.players||[]),...(data.injuries[g.home.code]?.players||[])];
    return(!q||[g.away.name,g.home.name,g.away.code,g.home.code,...rows.flatMap(i=>[i.player,i.playerZh])].join(' ').toLowerCase().includes(q));
  });
  $('games').innerHTML=games.map(g=>`<article class="game"><div class="game-header"><div class="match"><span>${esc(g.away.name)}</span><em>vs</em><span>${esc(g.home.name)}</span></div><div class="game-schedule"><span class="time">${esc(new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(g.start)))}</span>${esc(gameLabels[g.status]||(/[\u3400-\u9fff]/.test(g.status)?g.status:'赛程待确认'))}</div></div><div class="team-grid">${teamHTML(g.away)}${teamHTML(g.home)}</div></article>`).join('')||`<div class="empty">${day.state==='unavailable'?'赛程暂不可用，请稍后再试。':day.games.length?'没有符合筛选条件的比赛。':'该日期的赛程来源返回 0 场比赛。'}</div>`;
}
async function refresh(manual=false){
  if(location.protocol==='file:'){if(manual)alert('本地文件使用内嵌快照。请运行更新脚本，或通过本地服务器 / Pages 查看更新。');render();return;}
  $('refresh').disabled=true;
  try{
    const r=await fetch('data.json?t='+Date.now(),{cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
    const next=await r.json();if(next.schemaVersion!==1||!next.days?.[next.defaultDate]||!next.injuries)throw Error('快照格式不兼容');
    const followed=selected===data.defaultDate;data=next;if(followed)selected=next.defaultDate;render();
  }catch(e){render();$('health').hidden=false;$('health').textContent='更新检查暂未成功，当前保留上次数据。';}
  finally{$('refresh').disabled=false;}
}
$('dates').addEventListener('click',e=>{const b=e.target.closest('button[data-date]');if(b){selected=b.dataset.date;render();}});
$('search').addEventListener('input',render);$('refresh').addEventListener('click',()=>refresh(true));
render();refresh();setInterval(refresh,300000);
