
'use strict';
const pe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const playerName=p=>(window.NBA_PLAYER_NAMES||{})[String(p.nameOriginal||p.name||'').normalize('NFKD').replace(/[^a-zA-Z0-9]/g,'').toLowerCase()]||p.name;
const statNames=['得分','篮板','助攻','盖帽','抢断'];
function show(d){
 // A daily published edition stays visible until the next successful 15:30 edition.
 const valid=d?.schemaVersion===1&&d.state==='ready';
 const categories=valid?Object.values(d.categories):[];
 document.getElementById('prediction-content').innerHTML=statNames.map(label=>{
  const c=categories.find(c=>c.label===label);
  const rows=(c?.candidates||[]).filter(p=>p.recommendationEligible===true&&['unknown','available'].includes(p.status)).slice(0,3);
  return `<article class="simple-prediction"><h2>${label}王</h2>${rows.length?`<ol class="reference-top3">${rows.map(p=>`<li><strong>${pe(playerName(p))}</strong><span>${(p.leaderShare*100).toFixed(1)}%</span></li>`).join('')}</ol>`:'<p class="prediction-empty">数据更新中，请稍后查看</p>'}</article>`;
 }).join('');
}
async function load(){try{const r=await fetch('predictions.json?t='+Date.now(),{cache:'no-store'});if(!r.ok)throw Error();show(await r.json());}catch(e){show(null);}}
load();
